#include <reg51.h>
void main() {
    unsigned int num1 = 0x2222;
    unsigned int num2 = 0xBBBB;
    unsigned long int product;
    while (1) {
        // CAST BOTH to ensure 32-bit math
        product = (unsigned long int)num1 * (unsigned long int)num2;
        P0 = (product & 0xFF);
        P1 = ((product >> 8) & 0xFF);
        P2 = ((product >> 16) & 0xFF);
        P3 = ((product >> 24) & 0xFF);
    }
}