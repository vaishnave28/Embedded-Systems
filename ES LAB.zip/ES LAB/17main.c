#include <reg51.h>

void main() 
{ 
    unsigned int num1 = 0x2222; 
    unsigned int num2 = 0xBBBB; 
    unsigned long int product; 

    while (1) 
    { 
        // Force 32-bit unsigned multiplication
        product = (unsigned long int)num1 * (unsigned long int)num2; 

        // Assign results to Ports
        P0 = (unsigned char)(product & 0xFF);         // Expected: 0xA2
        P1 = (unsigned char)((product >> 8) & 0xFF);  // Expected: 0x99
        P2 = (unsigned char)((product >> 16) & 0xFF); // Expected: 0xEF
        P3 = (unsigned char)((product >> 24) & 0xFF); // Expected: 0x18
    } 
}