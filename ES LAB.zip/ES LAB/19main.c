#include <reg51.h>

void main() 
{ 
    unsigned int i; 
    unsigned char num = 12; 
    unsigned long factorial = 1; // Initialize to 1

    for (i = 1; i <= num; i++) 
    { 
        factorial = factorial * i; 
    } 

    // Result of 12! is 0x1C8CFC00
    P0 = (unsigned char)(factorial & 0xFF);         // 0x00
    P1 = (unsigned char)((factorial >> 8) & 0xFF);  // 0xFC
    P2 = (unsigned char)((factorial >> 16) & 0xFF); // 0x8C
    P3 = (unsigned char)((factorial >> 24) & 0xFF); // 0x1C

    while(1); // Keep result on ports
}