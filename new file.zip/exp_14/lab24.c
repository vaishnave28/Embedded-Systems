#include <lpc214x.h>

void delay(unsigned int k);

int main(void)
{
     PINSEL = 0x00000000;   
IO0CLR = 0x0000FF00;   

    while(1)
    {
       IO0SET = 0x0000FF00;  
        delay(1000);

        IO0CLR = 0x0000FF00;   
        delay(1000);
    }
}

void delay(unsigned int k)
{
    unsigned int i, j;
    for(j = 0; j < k; j++)
        for(i = 0; i < 800; i++);
}
