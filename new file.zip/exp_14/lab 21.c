#include <reg51.h> 
#include <stdio.h>
void main (void)
{
SCON = 0x50; 
TR1 = 1; 
TI = 1; 
{
printf ("Hello World ! \n ");
}
}